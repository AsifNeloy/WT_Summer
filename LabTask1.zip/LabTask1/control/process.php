<html>
    <body>
        <h1>Page 2</h1>
</body>
</html>